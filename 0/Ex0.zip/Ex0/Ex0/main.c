#include <stdio.h>
void main()
{
	printf("Our IDs are: 204058697_201631678\n");
}